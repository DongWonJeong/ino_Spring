package com.sparta.myselectshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyselectshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
