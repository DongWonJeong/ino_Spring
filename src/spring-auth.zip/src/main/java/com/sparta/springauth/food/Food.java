package com.sparta.springauth.food;

public interface Food {
    void eat();
}