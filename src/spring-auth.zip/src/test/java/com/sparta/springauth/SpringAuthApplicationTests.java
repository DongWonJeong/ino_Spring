package com.sparta.springauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAuthApplicationTests {

    @Test
    void contextLoads() {
    }

}
