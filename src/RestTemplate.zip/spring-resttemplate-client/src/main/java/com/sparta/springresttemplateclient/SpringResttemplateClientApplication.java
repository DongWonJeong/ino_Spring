package com.sparta.springresttemplateclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringResttemplateClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringResttemplateClientApplication.class, args);
    }

}
