package com.sparta.springresttemplateclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResttemplateClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
