package com.sparta.springresttemplateserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringResttemplateServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
