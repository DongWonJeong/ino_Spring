package com.sparta.springresttemplateserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringResttemplateServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringResttemplateServerApplication.class, args);
    }

}
