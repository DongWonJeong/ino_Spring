package com.sparta.memo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
