package com.example.jpa_relation_test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaRelationTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(JpaRelationTestApplication.class, args);
    }

}
