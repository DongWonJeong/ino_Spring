package com.example.jpa_relation_test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaRelationTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
